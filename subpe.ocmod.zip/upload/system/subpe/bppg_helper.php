<?php


class BubpePayment { 

static function performChecks()
    {
        // required values
        $check_values = array(
            'PAY_ID' => $this->pay_id,
            'ORDER_ID' => $this->order_id,
            'RETURN_URL' => $this->return_url,
            'CUST_EMAIL' => $this->cust_email,
            'CUST_PHONE' => $this->cust_phone,
            'AMOUNT' => $this->amount,
            'TXNTYPE' => $this->txn_type,
            'CURRENCY_CODE' => $this->currency_code
        );

        foreach ($check_values as $key => $value) {
            if (!isset($value)) {
                die('<h4>'.$key.' value is missing</h4>');
            }
        }
    }



    static function generateHash($postdata,$key) {
       ksort($postdata);
        $all = '';
        foreach ($postdata as $name => $value) {
            $all .= $name."=".$value."~";
        }
        $all = substr($all, 0, -1);
        $all .= $key;
        return strtoupper(hash('sha256', $all));
    }

    static function createTransactionRequest()
    {
        $this->performChecks();
        $post_variables = array(
            "PAY_ID" => $this->_empty($this->pay_id),
            "ORDER_ID" => $this->_empty($this->order_id),
            "RETURN_URL" => $this->_empty($this->return_url),
            "CUST_EMAIL" => $this->_empty($this->cust_email),
            "CUST_NAME" => $this->_empty($this->cust_name),
            "CUST_STREET_ADDRESS1" => $this->_empty($this->cust_street_address1),
            "CUST_CITY" => $this->_empty($this->cust_city),
            "CUST_STATE" => $this->_empty($this->cust_state),
            "CUST_COUNTRY" => $this->_empty($this->cust_country),
            "CUST_ZIP" => $this->_empty($this->cust_zip),
            "CUST_PHONE" => $this->_empty($this->cust_phone),
            "CURRENCY_CODE" => $this->_empty($this->currency_code),
            "AMOUNT" => $this->_empty($this->amount),
            "PRODUCT_DESC" => $this->_empty($this->product_desc),
            "CUST_SHIP_STREET_ADDRESS1" => $this->_empty($this->cust_ship_street_address1),
            "CUST_SHIP_CITY" => $this->_empty($this->cust_ship_city),
            "CUST_SHIP_STATE" => $this->_empty($this->cust_ship_state),
            "CUST_SHIP_COUNTRY" => $this->_empty($this->cust_ship_country),
            "CUST_SHIP_ZIP" => $this->_empty($this->cust_ship_zip),
            "CUST_SHIP_PHONE" => $this->_empty($this->cust_ship_phone),
            "CUST_SHIP_NAME" => $this->_empty($this->cust_ship_name),
            "TXNTYPE" => $this->_empty($this->txn_type),
        );
        $post_variables['HASH'] = $this->generateHash($post_variables);
        return $post_variables;
    }


    static function validateResponse($response,$key)
    {
        //print_r($response);exit;

     $postdata = $response;
      $salt=$key;

        ksort($postdata);
        unset($postdata["HASH"]);
 
        $all = '';
        foreach ($postdata as $name => $value) {
            $all .= $name."=".$value."~";
        }
        $all = substr($all, 0, -1);
        $all .= $salt;
        $generated_hash = strtoupper(hash('sha256', $all));
        if ($response['HASH'] == $generated_hash) {
            return true;
        } else {
            return false;
        }
    }





}