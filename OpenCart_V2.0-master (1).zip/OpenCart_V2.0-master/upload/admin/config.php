<?php
// HTTP
define('HTTP_SERVER', 'http://www.inducosolutions.com/bharathi_opencart_2.0/admin/');
define('HTTP_CATALOG', 'http://www.inducosolutions.com/bharathi_opencart_2.0/');

// HTTPS
define('HTTPS_SERVER', 'http://www.inducosolutions.com/bharathi_opencart_2.0/admin/');
define('HTTPS_CATALOG', 'http://www.inducosolutions.com/bharathi_opencart_2.0/');

// DIR
define('DIR_APPLICATION', '/home1/inducos4/public_html/bharathi_opencart_2.0/admin/');
define('DIR_SYSTEM', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/');
define('DIR_LANGUAGE', '/home1/inducos4/public_html/bharathi_opencart_2.0/admin/language/');
define('DIR_TEMPLATE', '/home1/inducos4/public_html/bharathi_opencart_2.0/admin/view/template/');
define('DIR_CONFIG', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/config/');
define('DIR_IMAGE', '/home1/inducos4/public_html/bharathi_opencart_2.0/image/');
define('DIR_CACHE', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/cache/');
define('DIR_DOWNLOAD', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/download/');
define('DIR_UPLOAD', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/upload/');
define('DIR_LOGS', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/logs/');
define('DIR_MODIFICATION', '/home1/inducos4/public_html/bharathi_opencart_2.0/system/modification/');
define('DIR_CATALOG', '/home1/inducos4/public_html/bharathi_opencart_2.0/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'inducos4_bharath');
define('DB_PASSWORD', 'Rajesh123');
define('DB_DATABASE', 'inducos4_bharathipay_opencart');
define('DB_PREFIX', 'oc_');
