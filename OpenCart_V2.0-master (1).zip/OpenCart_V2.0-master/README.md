# BharthiPay for Opencart 2.x

======================================
= Installation
======================================
  Step 1:
    Unzip the downloaded package.
	
	 
  Step 2 : 
     Upload all files from /upload folder to the root of your opencart installation. No files will be overwritten, if you install the extension first time


  Step 3:
    Go to admin -> Extensions -> Payments -> Avant Garde Payment:
      - Click "Install" button and Edit it.


  Step 4:
    Edit "Avant Garde Payment" 
     - Fill all the Data
	 - BhartiPay Pay ID  - Merchant ID use for the BhartiPay service.
	 - Salt - BhartiPay Key use for the BhartiPay service.
	 - Test Mode - No - will cost amount from users, Yes - Free use(demo) , It will not cost any amount.
	 - Total : The checkout total the order must reach before this payment method becomes active.
	 - Order Status  : Status of order after successfull transaction.
	 - Geo Zone : Select zone.
	 - Status : Enable / Disabled
	 - Sort Order : Order of the payment method in checkout process
	 - and Save
 

- Happy 
;-) Again, ENJOY

